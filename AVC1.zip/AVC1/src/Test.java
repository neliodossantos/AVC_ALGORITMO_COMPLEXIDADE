//Autor: Nélio dos Santos
//1ºAvaliação
//Cadeira: Algoritmo e Complexidade
// Docente - Professor Pedro Mbote

// importando as bibliotecas
import org.junit.runner.JUnitCore;
import org.junit.runner.Result;
import org.junit.runner.notification.Failure;

public class Test {
    public static void main(String[] args) {
        // Executando os testes JUnit
        Result resultadoTestePortaLogicaAND = JUnitCore.runClasses(TestPortaLogicaAND2.class);
        Result resultadoTestePortaLogicaAND3 = JUnitCore.runClasses(TestPortaLogicaAND3.class);

        // Exibindo os resultados dos testes JUnit para PortaLogicaAND
        for (Failure falha : resultadoTestePortaLogicaAND.getFailures()) {
            System.out.println(falha.toString());
        }
        System.out.println("Teste PortaLogicaAND passou: " + resultadoTestePortaLogicaAND.wasSuccessful());

        // Exibindo os resultados dos testes JUnit para PortaLogicaAND3
        for (Failure falha : resultadoTestePortaLogicaAND3.getFailures()) {
            System.out.println(falha.toString());
        }
        System.out.println("Teste PortaLogicaAND3 passou: " + resultadoTestePortaLogicaAND3.wasSuccessful());

        // Testando PortaLogicaAND
        PortaLogicaAND2 porta1 = new PortaLogicaAND2(false, false);
        PortaLogicaAND2 porta2 = new PortaLogicaAND2(false, true);
        PortaLogicaAND2 porta3 = new PortaLogicaAND2(true, false);
        PortaLogicaAND2 porta4 = new PortaLogicaAND2(true, true);

        System.out.println("Porta 1: Entradas = " + porta1.obterEntradas() + ", Saída = " + porta1.obterSaida());
        System.out.println("Porta 2: Entradas = " + porta2.obterEntradas() + ", Saída = " + porta2.obterSaida());
        System.out.println("Porta 3: Entradas = " + porta3.obterEntradas() + ", Saída = " + porta3.obterSaida());
        System.out.println("Porta 4: Entradas = " + porta4.obterEntradas() + ", Saída = " + porta4.obterSaida());

        // Testando PortaLogicaAND3
        boolean entrada1 = true;
        boolean entrada2 = false;
        boolean entrada3 = true;
        boolean saida = PortaLogicaAND3.calcularSaida(entrada1, entrada2, entrada3);

        System.out.println("Porta AND3 com Entrada 1 = " + entrada1 + ", Entrada 2 = " + entrada2 +
                ", Entrada 3 = " + entrada3 + ", Saída = " + saida);
    }
}
