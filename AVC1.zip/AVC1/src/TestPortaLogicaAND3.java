//Autor: Nélio dos Santos
//1ºAvaliação
//Cadeira: Algoritmo e Complexidade
// Docente - Professor Pedro Mbote

// importando as bibliotecas
import static org.junit.Assert.*;
import org.junit.Test;

public class TestPortaLogicaAND3 {
    @Test
    public void testarPortaLogicaAND3() {
        // Testando combinações de entrada que devem produzir saída verdadeira e falsa
        assertFalse(PortaLogicaAND3.calcularSaida(false, false, false));
        assertFalse(PortaLogicaAND3.calcularSaida(false, false, true));
        assertFalse(PortaLogicaAND3.calcularSaida(false, true, false));
        assertFalse(PortaLogicaAND3.calcularSaida(true, false, false));
        assertTrue(PortaLogicaAND3.calcularSaida(true, true, true));
        assertFalse(PortaLogicaAND3.calcularSaida(true, true, false));
        assertFalse(PortaLogicaAND3.calcularSaida(true, false, true));
        assertFalse(PortaLogicaAND3.calcularSaida(false, true, true));
    }
}
