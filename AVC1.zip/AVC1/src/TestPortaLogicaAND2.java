import static org.junit.Assert.*;
import org.junit.Test;
//Autor: Nélio dos Santos
//1ºAvaliação
//Cadeira: Algoritmo e Complexidade
// Docente - Professor Pedro Mbote

public class TestPortaLogicaAND2 {
    @Test
    public void testarPortaLogicaAND() {
        // Criando objetos PortaLogicaAND com diferentes combinações de entrada
        PortaLogicaAND2 porta1 = new PortaLogicaAND2(false, false);
        PortaLogicaAND2 porta2 = new PortaLogicaAND2(false, true);
        PortaLogicaAND2 porta3 = new PortaLogicaAND2(true, false);
        PortaLogicaAND2 porta4 = new PortaLogicaAND2(true, true);

        // Verificando os valores de saída para cada combinação de entrada
        assertFalse(porta1.obterSaida());
        assertFalse(porta2.obterSaida());
        assertFalse(porta3.obterSaida());
        assertTrue(porta4.obterSaida());
    }
}
