//Autor: Nélio dos Santos
//1ºAvaliação
//Cadeira: Algoritmo e Complexidade
// Docente - Professor Pedro Mbote


// Classe para uma porta lógica AND com três entradas
class PortaLogicaAND3 {
    // Método para calcular a saída usando a classe PortaLogicaAND
    public static boolean calcularSaida(boolean entrada1, boolean entrada2, boolean entrada3) {
        PortaLogicaAND2 porta1 = new PortaLogicaAND2(entrada1, entrada2);
        boolean saidaParcial = porta1.obterSaida();

        PortaLogicaAND2 porta2 = new PortaLogicaAND2(saidaParcial, entrada3);
        return porta2.obterSaida();
    }
}