//Autor: Nélio dos Santos
//1ºAvaliação
//Cadeira: Algoritmo e Complexidade
// Docente - Professor Pedro Mbote

class PortaLogicaAND2 {
    private boolean entrada1;
    private boolean entrada2;

    // Construtor
    public PortaLogicaAND2(boolean entrada1, boolean entrada2) {
        this.entrada1 = entrada1;
        this.entrada2 = entrada2;
    }

    // Método para obter valores das entradas
    public String obterEntradas() {
        return "Entrada 1: " + entrada1 + ", Entrada 2: " + entrada2;
    }

    // Método para obter o valor da saída
    public boolean obterSaida() {
        return entrada1 && entrada2;
    }
}