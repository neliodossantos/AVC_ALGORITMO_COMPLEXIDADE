import org.junit.runner.JUnitCore;
import org.junit.runner.Result;
import org.junit.runner.notification.Failure;

//Classe principal
public class Main {

    public static void main(String[] args) {
        // Exemplo de uso da classe
        PerfilSaude pessoa = new PerfilSaude("João", "Silva", "Masculino", 5, 10, 1985, 1.75, 70);

        // Imprimir informações
        System.out.println("Nome: " + pessoa.getNome() + " " + pessoa.getSobrenome());
        System.out.println("Sexo: " + pessoa.getSexo());
        System.out.println("Data de Nascimento: " + pessoa.getMesNascimento() + "/" + pessoa.getDiaNascimento() + "/" + pessoa.getAnoNascimento());
        System.out.println("Altura: " + pessoa.getAltura() + "m");
        System.out.println("Peso: " + pessoa.getPeso() + "kg");

        // Calcular e imprimir idade, IMC, intervalo de frequência cardíaca máxima e frequência cardíaca alvo
        System.out.println("Idade: " + pessoa.calcularIdade() + " anos");
        System.out.println("IMC: " + pessoa.calcularIMC());
        System.out.println("Intervalo de Frequência Cardíaca Máxima: " + pessoa.calcularFrequenciaCardiacaMaxima() + " bpm");
        System.out.println("Frequência Cardíaca Alvo: " + pessoa.calcularFrequenciaCardiacaAlvo());

    }
}