public class PerfilSaude {
    private String nome;
    private String sobrenome;
    private String sexo;
    private int mesNascimento;
    private int diaNascimento;
    private int anoNascimento;
    private double altura; // em metros
    private double peso; // em quilogramas

    // Construtor
    public PerfilSaude(String nome, String sobrenome, String sexo, int mesNascimento, int diaNascimento, int anoNascimento, double altura, double peso) {
        this.nome = nome;
        this.sobrenome = sobrenome;
        this.sexo = sexo;
        this.mesNascimento = mesNascimento;
        this.diaNascimento = diaNascimento;
        this.anoNascimento = anoNascimento;
        this.altura = altura;
        this.peso = peso;
    }

    // Métodos set e get para cada atributo
    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getNome() {
        return nome;
    }

    public void setSobrenome(String sobrenome) {
        this.sobrenome = sobrenome;
    }

    public String getSobrenome() {
        return sobrenome;
    }

    public void setSexo(String sexo) {
        this.sexo = sexo;
    }

    public String getSexo() {
        return sexo;
    }

    public void setMesNascimento(int mesNascimento) {
        this.mesNascimento = mesNascimento;
    }

    public int getMesNascimento() {
        return mesNascimento;
    }

    public void setDiaNascimento(int diaNascimento) {
        this.diaNascimento = diaNascimento;
    }

    public int getDiaNascimento() {
        return diaNascimento;
    }

    public void setAnoNascimento(int anoNascimento) {
        this.anoNascimento = anoNascimento;
    }

    public int getAnoNascimento() {
        return anoNascimento;
    }

    public void setAltura(double altura) {
        this.altura = altura;
    }

    public double getAltura() {
        return altura;
    }

    public void setPeso(double peso) {
        this.peso = peso;
    }

    public double getPeso() {
        return peso;
    }

    // Método para calcular a idade em anos
    public int calcularIdade() {
        // Supondo que estamos em 2024
        int anoAtual = 2024;
        int idade = anoAtual - anoNascimento;

        // Ajustar idade se ainda não tiver feito aniversário neste ano
        if (mesNascimento > anoAtual || (mesNascimento == anoAtual && diaNascimento > mesNascimento)) {
            idade--;
        }

        return idade;
    }

    // Método para calcular o índice de massa corporal (IMC)
    public double calcularIMC() {
        return peso / (altura * altura);
    }

    // Método para calcular o intervalo de frequência cardíaca máxima
    public int calcularFrequenciaCardiacaMaxima() {
        return 220 - calcularIdade();
    }

    // Método para calcular a frequência cardíaca alvo
    public String calcularFrequenciaCardiacaAlvo() {
        double frequenciaCardiacaMaxima = calcularFrequenciaCardiacaMaxima();
        double limiteInferior = frequenciaCardiacaMaxima * 0.5;
        double limiteSuperior = frequenciaCardiacaMaxima * 0.85;
        return limiteInferior + " - " + limiteSuperior + " bpm";
    }
}
