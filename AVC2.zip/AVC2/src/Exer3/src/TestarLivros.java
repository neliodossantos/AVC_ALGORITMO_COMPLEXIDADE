
public class TestarLivros {
    public static void main(String[] args) {
        // Cria um objeto livrofavorito do tipo Livro
        Livro livroFavorito = new Livro();

        // Altera o atributo titulo para “O Pequeno Príncipe”
        livroFavorito.setTitulo("O Pequeno Príncipe");

        // Altera o atributo qtdPaginas para 98
        livroFavorito.setQtdPaginas(98);

        // Escreve na tela a mensagem: “O livro X possui Y páginas”
        System.out.println("O livro " + livroFavorito.getTitulo() + " possui " + livroFavorito.getQtdPaginas() + " páginas");

        // Altera a quantidade de paginasLidas para 20
        livroFavorito.setPaginasLidas(20);

        // Chama o método verificarProgresso
        livroFavorito.verificarProgresso();

        // Altera a quantidade de paginasLidas para 50
        livroFavorito.setPaginasLidas(50);

        // Chama o método verificarProgresso
        livroFavorito.verificarProgresso();

        // Instancia outros 10 livros no método main e chama os métodos desenvolvidos
        for (int i = 0; i < 10; i++) {
            Livro livro = new Livro("Livro " + (i + 1), 100);
            livro.setPaginasLidas(50);
            livro.verificarProgresso();
        }
    }
}
