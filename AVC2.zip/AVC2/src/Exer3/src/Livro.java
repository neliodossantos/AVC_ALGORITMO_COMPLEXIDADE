public class Livro {

    private String titulo;
    private int qtdPaginas;
    private int paginasLidas;

    public Livro() {
    }

    public Livro(String titulo, int qtdPaginas) {
        this.titulo = titulo;
        this.qtdPaginas = qtdPaginas;
        this.paginasLidas = 0;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public int getQtdPaginas() {
        return qtdPaginas;
    }

    public void setQtdPaginas(int qtdPaginas) {
        this.qtdPaginas = qtdPaginas;
    }

    public int getPaginasLidas() {
        return paginasLidas;
    }

    public void setPaginasLidas(int paginasLidas) {
        this.paginasLidas = paginasLidas;
    }

    public void verificarProgresso() {
        if (paginasLidas == qtdPaginas) {
            System.out.println("Parabéns! Você terminou de ler " + titulo + "!");
        } else {
            int porcentagem = (paginasLidas * 100) / qtdPaginas;
            System.out.println("Você já leu " + porcentagem + "% do livro " + titulo + ". Faltam " + (qtdPaginas - paginasLidas) + " páginas para terminar.");
        }
    }

}
