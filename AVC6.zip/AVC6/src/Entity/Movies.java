package Entity;

import java.util.*;
import java.util.stream.Collectors;

public class Movies {
    private List<Movie> movies = new ArrayList<>();
    public List<Movie> getMovies() {
        return movies;
    }
}
