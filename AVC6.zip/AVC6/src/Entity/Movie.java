package Entity;



import java.util.*;
import java.util.stream.Collectors;

public class Movie {
    private String title;
    private String director;
    private int duration;
    private int releaseYear;

    public Movie(String title,String director,int duration ,int releaseYear){
        this.title = title;
        this.director = director;
        this.duration = duration;
        this.releaseYear = releaseYear;
    }


    @Override
    public String toString() {
        return title + " (" + releaseYear + ")";
    }
    public int getDuration() {
        return duration;
    }

    public String getDirector() {
        return director;
    }

    public String getTitle() {
        return title;
    }
    public int getReleaseYear() {
        return releaseYear;
    }
}

