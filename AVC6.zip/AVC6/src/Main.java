import Entity.Movie;
import Entity.Movies;

import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

public class Main {
    public static void main(String[] args) {

        Movie m1 = new Movie("Fear and Desire","Stanley Kubrick",120,1952);
        Movie m2 = new Movie("Spartacus","Stanley Kubrick",60,1960);
        Movie m3 = new Movie("Capitão América: Guerra Civil","Anthony Russo",120,2016);
        Movie m4 = new Movie("Lolita","Stanley Kubrick",90,1962);
        Movie m5 = new Movie("Batman - Cavaleiro das Trevas ","Christopher Nolan",120,2006);
        Movies movies = new Movies();


        movies.getMovies().add(m1);
        movies.getMovies().add(m2);
        movies.getMovies().add(m3);
        movies.getMovies().add(m4);
        movies.getMovies().add(m5);

        long numeroDeFilmes = movies.getMovies().stream().count();
        System.out.println("Número de filmes: " + numeroDeFilmes);

        long numeroDeFilmesKubrick = movies.getMovies().stream()
                .filter(movie -> "Stanley Kubrick".equals(movie.getDirector()))
                .count();
        System.out.println("Número de filmes de Stanley Kubrick: " + numeroDeFilmesKubrick);

        System.out.println("-------------------------------------------------------------");
        List<Movie> filmesCurtaDuracao = movies.getMovies().stream()
                .filter(movie -> movie.getDuration() < 100)
                .collect(Collectors.toList());
        System.out.println("Filmes com duração inferior a 100 minutos: " + filmesCurtaDuracao);

        System.out.println("-------------------------------------------------------------");

        Map<String, List<Movie>> diretoresEFilmes = movies.getMovies().stream()
                .collect(Collectors.groupingBy(Movie::getDirector));
        System.out.println("Mapa de diretores e seus filmes: " + diretoresEFilmes);

        System.out.println("-------------------------------------------------------------");

        Optional<Movie> filmeMaisLongo = movies.getMovies().stream()
                .max(Comparator.comparingInt(Movie::getDuration));
        Optional<Movie> filmeMaisCurto = movies.getMovies().stream()
                .min(Comparator.comparingInt(Movie::getDuration));
        System.out.println("Filme mais longo: " + filmeMaisLongo.orElse(null));
        System.out.println("Filme mais curto: " + filmeMaisCurto.orElse(null));

        System.out.println("-------------------------------------------------------------");

        List<Movie> filmesOrdenadosPorAno = movies.getMovies().stream()
                .sorted(Comparator.comparingInt(Movie::getReleaseYear))
                .collect(Collectors.toList());
        System.out.println("Filmes em ordem cronológica: " + filmesOrdenadosPorAno);
    }

}