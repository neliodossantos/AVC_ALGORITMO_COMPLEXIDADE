package Entity;
import Interface.OperacaoFinanceira;
import Interface.Transacao;

/**
 * Classe que representa uma Transação Financeira.
 */
public  class TransacaoFinanceira implements Transacao, OperacaoFinanceira {
    private double montante;

    /**
     * Construtor da classe TransacaoFinanceira.
     */
    public TransacaoFinanceira(double montante) {
        // Implementação do construtor
    }

    @Override
    public void executar() {
        // Implementação do método executar
    }

    @Override
    public double calcularMontante() {
        // Implementação do método calcularMontante
        return 0.0;
    }
}

