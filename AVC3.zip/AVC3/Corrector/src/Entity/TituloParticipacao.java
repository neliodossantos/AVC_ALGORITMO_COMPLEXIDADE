package Entity;

import java.time.LocalDate;

/**
 * Classe que representa um Título de Participação.
 */
public class TituloParticipacao {
    private String designacao;
    private LocalDate dataEmissao;
    private double valorFacial;

    /**
     * Construtor da classe TituloParticipacao.
     */
    public TituloParticipacao(String designacao, LocalDate dataEmissao, double valorFacial) {
        // Implementação do construtor
    }

    // Métodos getters e setters para os atributos
    // Implemente conforme necessário
}

/**
 * Interface para representar uma Transação.
 */



