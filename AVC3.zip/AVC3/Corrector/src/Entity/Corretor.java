package Entity;
import java.time.LocalDate;

/**
 * Classe que representa um Corretor.
 */
public  class Corretor {
    private int numero;
    private String nome;
    private LocalDate dataAdmissao;
    private LocalDate dataRescisao;
    private String telefone;
    private double salarioBase;
    private double comissao;

    /**
     * Construtor da classe Corretor.
     */
    public Corretor(int numero, String nome, LocalDate dataAdmissao, String telefone, double salarioBase) {
        this.numero = numero;
        this.nome = nome;
        this.dataAdmissao = dataAdmissao;
        this.telefone = telefone;
        this.salarioBase = salarioBase;
    }

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public LocalDate getDataAdmissao() {
        return dataAdmissao;
    }

    public void setDataAdmissao(LocalDate dataAdmissao) {
        this.dataAdmissao = dataAdmissao;
    }

    public LocalDate getDataRescisao() {
        return dataRescisao;
    }

    public void setDataRescisao(LocalDate dataRescisao) {
        this.dataRescisao = dataRescisao;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public double getSalarioBase() {
        return salarioBase;
    }

    public void setSalarioBase(double salarioBase) {
        this.salarioBase = salarioBase;
    }

    public double getComissao() {
        return comissao;
    }

    public void setComissao(double comissao) {
        this.comissao = comissao;
    }
}