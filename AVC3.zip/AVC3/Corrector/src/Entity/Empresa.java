package Entity;
/**
 * Classe que representa uma Empresa.
 */
class Empresa extends Pessoa {
    private String setor;
    private String paisOrigem;

    // Métodos getters e setters para os atributos
    public String getNome(){return this.nome};
    public String getPaisOrigem(){return this.paisOrigem};

    public void setNome(String nome){this.nome = nome;};
    public String getPaisOrigem(){return this.paisOrigem = paisOrigem};
}

