package Entity;

/**
 * Classe abstrata que representa uma Pessoa.
 */
abstract class Pessoa {
    private String nome;
    private String telefone;

    // Métodos getters e setters para os atributos
    // Implemente conforme necessário
}