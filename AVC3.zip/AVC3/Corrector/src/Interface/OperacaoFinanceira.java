package Interface;

/**
 * Interface para representar uma Operação Financeira.
 */

public interface OperacaoFinanceira {
        double calcularMontante();
}
