package Interface;

import Entity.TituloParticipacao;

/**
 * Interface para representar uma Carteira de Títulos.
 */
public interface Carteira {
    void adicionarTitulo(TituloParticipacao titulo, int quantidade);
    void removerTitulo(TituloParticipacao titulo);
}