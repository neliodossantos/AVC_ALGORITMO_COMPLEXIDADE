package Interface;

import Entity.Apartamento;
import Entity.Condomino;
import Entity.Edificio;

public interface ICondominio {
    public void adicionarEdificio(Edificio edificio);
    public void adicionarApartamento(Apartamento apartamento);
    void adicionarCondominio(Condomino condomino);
    public void listar();

}
