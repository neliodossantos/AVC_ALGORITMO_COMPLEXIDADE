package Entity;

public class DespesasComuns extends Base {
    private String descricao;
    private double valor;
    private Edificio edificio;
    private static int totalDespesasComuns = 0;


    public DespesasComuns(String descricao , double valor , Edificio edificio){
        this.descricao = descricao;
        this.valor = valor;
        this.edificio = edificio;
    }
    public int getTotalDespesasComuns() {
        return this.totalDespesasComuns;
    }

    public void setTotalDespesasComuns(int totalDespesasComuns) {
        DespesasComuns.totalDespesasComuns = totalDespesasComuns;
    }

    public Edificio getEdificio() {
        return edificio;
    }

    public void setEdificio(Edificio edificio) {
        this.edificio = edificio;
    }

    public double getValor() {
        return valor;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }
}
