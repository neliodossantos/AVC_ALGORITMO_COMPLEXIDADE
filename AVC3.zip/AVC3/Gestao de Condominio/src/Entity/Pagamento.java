package Entity;

public class Pagamento extends Base {
    private Condomino condomino;
    private double valor;
    private static int totalPagamento;
    public Pagamento(Condomino condomino , double valor){
        this.valor = valor;
        this.condomino = condomino;
    }

    public static int getTotalPagamento() {
        return totalPagamento;
    }

    public static void setTotalPagamento(int totalPagamento) {
        Pagamento.totalPagamento = totalPagamento;
    }
    public double getValor() {
        return valor;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }

    public Condomino getCondomino() {
        return condomino;
    }

    public void setCondomino(Condomino condomino) {
        this.condomino = condomino;
    }
}
