package Entity;
import java.time.LocalDate;
import java.util.Locale;


public class Base {
    private LocalDate  createdAt;
    private LocalDate updatedAt;

    public Base(){
        this.createdAt = LocalDate.now();
        this.updatedAt = LocalDate.now();
    }
    public LocalDate getCreatedAt() {
        return createdAt;
    }
    public LocalDate getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(LocalDate updatedAt) {
        this.updatedAt = LocalDate.now();
    }
}
