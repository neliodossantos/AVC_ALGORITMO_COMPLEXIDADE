package Entity;

import java.time.LocalDate;

public class Balancetes {
    private Edificio edificio;
    private LocalDate dataEmissao;
    private static int totalBalancetes = 0;


    public static int getTotalBalancetes() {
        return totalBalancetes;
    }

    public static void setTotalBalancetes(int totalBalancetes) {
        Balancetes.totalBalancetes = totalBalancetes;
    }

    public LocalDate getDataEmissao() {
        return dataEmissao;
    }
    public void setDataEmissao(LocalDate dataEmissao) {
        this.dataEmissao = dataEmissao;
    }
    public Edificio getEdificio() {
        return edificio;
    }
    public void setEdificio(Edificio edificio) {
        this.edificio = edificio;
    }
}
