package Entity;

import Interface.ICondominio;

public class Condominio extends Base  implements ICondominio {
    private String nome;
    private Edificio [] edificios;
    private Apartamento [] apartamentos;
    private Condomino[] condominos;

    private String endereco;

    Condominio(){};

    public Condominio(String nome , String endereco){
        super();
        this.nome = nome;
        this.endereco = endereco;
        this.edificios = new Edificio[100];
        this.apartamentos = new Apartamento[100];
        this.condominos = new Condomino[100];
    }


    @Override
    public void adicionarEdificio(Edificio edificio){
        int totalEdificio = edificio.getTotalEdificio();
       if(totalEdificio < 100){
           this.edificios[totalEdificio++] = edificio;
           edificio.setTotalEdificio(totalEdificio);
       }else{
           System.out.println("Sem espaco para adicionar Edificio.");
       }
    }

    @Override
    public void adicionarApartamento(Apartamento apartamento){
        int totalApartamento = apartamento.getTotalApartamento();
        if(totalApartamento < 100){
            this.apartamentos[totalApartamento++] = apartamento;
            apartamento.setTotalApartamento(totalApartamento);
        }else{
            System.out.println("Sem espaco para adicionar Edificio.");
        }
    }

    @Override
    public void adicionarCondominio(Condomino condomino){
        int totalCondomino = condomino.getTotalCondomino();
        if(totalCondomino < 100){
            this.condominos[totalCondomino++] = condomino;
            condomino.setTotalCondomino(totalCondomino);
        }else{
            System.out.println("Sem espaco para adicionar condomino.");
        }
    }
    @Override
    public void listar(){
        for (Edificio edificio : edificios){
            if(edificio != null){
                System.out.println("Condominio: " + edificio.getCondominio().nome);
                System.out.println("Edificio : " + edificio.getNome());
                for (Apartamento apartamento : apartamentos){
                    if(apartamento != null) {
                        if (apartamento.getEdificio().getNome().equals(edificio.getNome())) {
                            System.out.println("Apartamento : " + apartamento.getNumeroApartamento());
                            for(Condomino condomino : condominos) {
                                if (condomino != null && edificio.getNome().equals(condomino.getApartamento().getEdificio().getNome())) {
                                    if (condomino.getApartamento().equals(apartamento)){
                                        System.out.println("Condomino : " + condomino.getNome());
                                    }
                                }
                            }
                        }
                    }
                }
                System.out.println("------------------------------------------------");
            }
        }
    }

}
