package Entity;

public class Edificio  extends  Base {
    private String nome;
    private Condominio condominio;
    private static int totalEdificio;
    private DespesasComuns [] despesasComuns;

    public Edificio(String nome , Condominio condominio){
        this.nome = nome;
        this.condominio = condominio;
        this.despesasComuns = new DespesasComuns[100];
    };

    public void adicionarDespesasComuns(DespesasComuns despesaComum){
        int total =despesaComum.getTotalDespesasComuns();
        if( total < 100){
            despesasComuns[total++] = despesaComum;
        }else
            System.out.println("Erro");
    }
    public String getNome() {
        return nome;
    }
    public void setNome(String nome) {
        this.nome = nome;
    }

    public Condominio getCondominio() {
        return condominio;
    }
    public void setCondominio(Condominio condominio) {
        this.condominio = condominio;
    }

    public int getTotalEdificio() {
        return totalEdificio;
    }
    public void setTotalEdificio(int totalEdificio) {
        Edificio.totalEdificio = totalEdificio;
    }

    public void listarDespesasComuns(){
        for(DespesasComuns despesaComum : despesasComuns){
            if(despesaComum != null){
                if(despesaComum.getEdificio() != null){
                    System.out.println("Edificio : " + despesaComum.getEdificio().getNome());
                    System.out.println("Despesas Comuns : " + despesaComum.getDescricao());
                    System.out.println("Valor : " + despesaComum.getValor());
                }
            }
        }
    }
}
