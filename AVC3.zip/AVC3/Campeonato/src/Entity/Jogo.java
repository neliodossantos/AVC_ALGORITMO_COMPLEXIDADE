package Entity;
import java.util.*;

// Entidade para representar um jogo
public class Jogo {
    private Selecao timeCasa;
    private Selecao timeVisitante;
    private int placarCasa;
    private int placarVisitante;

    public Jogo(Selecao timeCasa, Selecao timeVisitante, int placarCasa, int placarVisitante) {
        this.timeCasa = timeCasa;
        this.timeVisitante = timeVisitante;
        this.placarCasa = placarCasa;
        this.placarVisitante = placarVisitante;
    }


    public Selecao getTimeCasa() {
        return timeCasa;
    }

    public void setTimeCasa(Selecao timeCasa) {
        this.timeCasa = timeCasa;
    }

    public Selecao getTimeVisitante() {
        return timeVisitante;
    }

    public void setTimeVisitante(Selecao timeVisitante) {
        this.timeVisitante = timeVisitante;
    }

    public int getPlacarCasa() {
        return placarCasa;
    }

    public void setPlacarCasa(int placarCasa) {
        this.placarCasa = placarCasa;
    }

    public int getPlacarVisitante() {
        return placarVisitante;
    }

    public void setPlacarVisitante(int placarVisitante) {
        this.placarVisitante = placarVisitante;
    }
}

