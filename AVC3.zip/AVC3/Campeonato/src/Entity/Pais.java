package Entity;

// Entidade para representar um país
public class Pais {
    private String nome;

    public Pais(String nome) {
        this.nome = nome;
    }
}

