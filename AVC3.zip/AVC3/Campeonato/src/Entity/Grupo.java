package Entity;

import java.util.ArrayList;
import java.util.List;

public class Grupo {
    private static int totalGrupo;
    // Entidade para representar um grupo na fase de qualificação
        private String nome;
        private Selecao[] selecoes;

        public Grupo(String nome) {
            this.nome = nome;
            this.selecoes = new Selecao[100];
        }

    public int getTotalGrupo() {
        return totalGrupo;
    }
    public void setTotalGrupo(int totalGrupo) {
        this.totalGrupo = totalGrupo;
    }

    public void adicionarSelecao(Selecao selecao) {
            int total = selecao.getTotalSelecao();
            if(total<100){
                selecoes[total++] = selecao;
                selecao.setTotalSelecao(total);
            }else{
                System.out.println("Erro nao pode adicionar");
            }
        }
}
