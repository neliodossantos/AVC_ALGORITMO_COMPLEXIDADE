package Entity;

public abstract class Pessoa {
    protected String nome;
    protected int idade;

}
