package Entity;

public class Selecao {
        private String nome;
        private Pais pais;
        private Jogador [] jogadores;

        private static int totalSelecao;

        public Selecao(String nome, Pais pais) {
            this.nome = nome;
            this.pais = pais;
            this.jogadores = new Jogador[100];
        }
        public void adicionarJogador(Jogador jogador) {
            int total = jogador.getTotalJogadores();
            if(total<100){
                jogadores[total++] = jogador;
                jogador.setTotalJogadores(total);
            }else{
                System.out.println("Erro nao pode adicionar");
            }

        }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Pais getPais() {
        return pais;
    }

    public void setPais(Pais pais) {
        this.pais = pais;
    }

    public void setTotalSelecao(int totalSelecao) {
        this.totalSelecao = totalSelecao;
    }

    public int getTotalSelecao() {
        return totalSelecao;
    }
}
