package Entity;
import Entity.Utilizador;

// Classe para representar os funcionários
class Funcionario extends Utilizador {
    private int codigo;
    private String agencia;
    private double salario;

    // Construtor
    public Funcionario(int codigo, String agencia, double salario, String nome, String email, String senha) {
        this.codigo = codigo;
        this.agencia = agencia;
        this.salario = salario;
        this.nome = nome;
        this.email = email;
        this.senha = senha;
    }

    // Método para fazer login como funcionário
    @Override
    public boolean fazerLogin(String email, String senha) {
        return this.email.equals(email) && this.senha.equals(senha);
    }

    // Método para registar um novo funcionário
    @Override
    public void registar(String nome, String email, String senha) {
        this.nome = nome;
        this.email = email;
        this.senha = senha;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getAgencia() {
        return agencia;
    }

    public void setAgencia(String agencia) {
        this.agencia = agencia;
    }

    public double getSalario() {
        return salario;
    }

    public void setSalario(double salario) {
        this.salario = salario;
    }
}
