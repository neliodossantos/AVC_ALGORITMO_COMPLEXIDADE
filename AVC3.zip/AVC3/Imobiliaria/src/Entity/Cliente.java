package Entity;

// Classe para representar os clientes
public class Cliente extends Utilizador {
    private String endereco;
    private String telefone;

    // Construtore
    public Cliente(String nome, String email, String senha, String endereco, String telefone) {
        this.nome = nome;
        this.email = email;
        this.senha = senha;
        this.endereco = endereco;
        this.telefone = telefone;
    }
    // Método para fazer login como cliente
    @Override
    public boolean fazerLogin(String email, String senha) {
        return this.email.equals(email) && this.senha.equals(senha);
    }
    // Método para registar um novo cliente
    @Override
    public void registar(String nome, String email, String senha) {
        this.nome = nome;
        this.email = email;
        this.senha = senha;
    }

}
