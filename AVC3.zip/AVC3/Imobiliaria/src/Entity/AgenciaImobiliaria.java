package Entity;

import java.util.ArrayList;
import java.util.List;

// Classe para representar uma agência imobiliária
public class AgenciaImobiliaria {
    private String nome;
    private Funcionario [] funcionarios;
    private Propriedade [] propriedades;

    // Construtor
    public AgenciaImobiliaria(String nome) {
        this.nome = nome;
        this.funcionarios = new Funcionario[100];
        this.propriedades = new Propriedade[100];
    }

    // Métodos para adicionar funcionários, propriedades, etc.
    public void adicionarFuncionario(Funcionario funcionario) {
    }

    public void adicionarPropriedade(Propriedade propriedade) {
    }
}

