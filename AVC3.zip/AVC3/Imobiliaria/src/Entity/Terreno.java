package Entity;


// Classe para representar terrenos
public  class Terreno extends Propriedade {
    private boolean urbano;

    // Construtor
    public Terreno(int anoConstrucao, double area, String localizacao, boolean urbano) {
        super(anoConstrucao, area, localizacao);
        this.urbano = urbano;
    }

    // Método para exibir detalhes do terreno
    @Override
    public void exibirDetalhes() {
        String tipo = urbano ? "Urbano" : "Rural";
        System.out.println("Terreno: Tipo - " + tipo + ", Área - " + area + " m²");
    }
}
