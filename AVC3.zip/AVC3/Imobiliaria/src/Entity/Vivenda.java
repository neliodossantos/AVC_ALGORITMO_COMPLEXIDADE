package Entity;


// Classe para representar vivendas
public class Vivenda extends Propriedade {
    private String tipologia;
    private double preco;

    // Construtor
    public Vivenda(int anoConstrucao, double area, String localizacao, String tipologia, double preco) {
        super(anoConstrucao, area, localizacao);
        this.tipologia = tipologia;
        this.preco = preco;
    }

    // Método para exibir detalhes da vivenda
    @Override
    public void exibirDetalhes() {
        System.out.println("Vivenda: Tipologia - " + tipologia + ", Área - " + area + " m², Preço - " + preco + " AKZ");
    }
}

