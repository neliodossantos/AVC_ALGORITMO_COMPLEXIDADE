package Entity;

import Interface.Imovel;

public class Transacao extends Base {

    private String agencia;
    private Funcionario vendedor;
    private Imovel imovel;
    private Utilizador clienteComprador;
    private Proprietario proprietario;
    private static int totalTransacoes;

    public Transacao(){};
    public Transacao(String agencia , Funcionario vendedor , Imovel imovel , Utilizador cliente , Proprietario dono){
        this.agencia = agencia;
        this.vendedor = vendedor;
        this.imovel = imovel;
        this.clienteComprador = cliente;
        this.proprietario = dono;
    };

    public String getAgencia() {
        return agencia;
    }

    public void setAgencia(String agencia) {
        this.agencia = agencia;
    }

    public Funcionario getVendedor() {
        return vendedor;
    }

    public void setImovel(Imovel imovel) {
        this.imovel = imovel;
    }
    public void setVendedor(Funcionario vendedor) {
        this.vendedor = vendedor;
    }

    public void setProprietario(Proprietario proprietario) {
        this.proprietario = proprietario;
    }

    public void setClienteComprador(Utilizador clienteComprador) {
        this.clienteComprador = clienteComprador;
    }

    public Proprietario getProprietario() {
        return proprietario;
    }

    public Imovel getImovel() {
        return imovel;
    }

    public int getTotalTransacoes() {
        return totalTransacoes;
    }

    public void setTotalTransacoes(int totalTransacoes) {
        this.totalTransacoes = totalTransacoes;
    }

}
