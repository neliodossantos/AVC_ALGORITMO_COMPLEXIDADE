package Entidade;

public class DepositAccount {
}
