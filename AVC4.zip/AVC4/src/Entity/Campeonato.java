package Entity;

import java.time.LocalDate;

public class Campeonato {
    private  AtividadeDesportiva atividade;
    private  LocalDate dataInicio;
    private  LocalDate dataFim;
    private Equipa [] equipasParticipantes;
    private Partida [] partidas;

    private  int totalCampionatos;
    private int totalEquipa;
    private int totalPartidas;


    public Campeonato(AtividadeDesportiva atividade , LocalDate dataInicio , LocalDate dataFim){
        this.atividade = atividade;
        this.dataInicio = dataInicio;
        this.dataFim = dataFim;
        this.equipasParticipantes = new Equipa[100];
        this.partidas = new Partida[100];
    }
    public int getTotalEquipa() {
        return totalEquipa;
    }

    public void setTotalEquipa(int totalEquipa) {
        this.totalEquipa = totalEquipa;
    }

    public Equipa[] getEquipasParticipantes() {
        return equipasParticipantes;
    }

    public void setEquipasParticipantes(Equipa[] equipasParticipantes) {
        this.equipasParticipantes = equipasParticipantes;
    }

    public LocalDate getDataFim() {
        return dataFim;
    }

    public void setDataFim(LocalDate dataFim) {
        this.dataFim = dataFim;
    }

    public LocalDate getDataInicio() {
        return dataInicio;
    }

    public void setDataInicio(LocalDate dataInicio) {
        this.dataInicio = dataInicio;
    }
    public AtividadeDesportiva getAtividade() {
        return atividade;
    }

    public void setAtividade(AtividadeDesportiva atividade) {
        this.atividade = atividade;
    }

    public int getTotalCampionatos() {
        return totalCampionatos;
    }

    public void setTotalCampionatos(int totalCampionatos) {
        this.totalCampionatos = totalCampionatos;
    }

    public int getTotalPartidas() {
        return totalPartidas;
    }

    public void setTotalPartidas(int totalPartidas) {
        this.totalPartidas = totalPartidas;
    }

    public Partida[] getPartidas() {
        return partidas;
    }

    public void setPartidas(Partida[] partidas) {
        this.partidas = partidas;
    }

    public class Equipa {
        private String nome;
        private String mascote;

        public Equipa(String nome, String mascote){
            this.nome = nome;
            this.mascote = mascote;
        }

        public String getNome() {
            return nome;
        }

        public void setNome(String nome) {
            this.nome = nome;
        }

        public String getMascote() {
            return mascote;
        }

        public void setMascote(String mascote) {
            this.mascote = mascote;
        }

    }
    public class Partida {
        private  Equipa [] equipas = new Equipa[2];
        private  LocalDate DataJogo;
        private int [] resultado = new int[2];
        private int numPartida;

        public Partida(Equipa equipa1 , Equipa equipa2 , int ponto1 , int ponto2){
            this.equipas[0] = equipa1;
            this.equipas[1] = equipa2;
            this.resultado[0] = ponto1;
            this.resultado[1] = ponto2;
            this.DataJogo = LocalDate.now();
        }
        public Equipa[] getEquipas() {
            return equipas;
        }

        public void setEquipas(Equipa[] equipas) {
            this.equipas = equipas;
        }

        public LocalDate getDataJogo() {
            return DataJogo;
        }

        public void setDataJogo(LocalDate dataJogo) {
            DataJogo = dataJogo;
        }

        public int[] getResultado() {
            return resultado;
        }

        public void setResultado(int[] resultado) {
            this.resultado = resultado;
        }

        public int getNumPartida() {
            return numPartida;
        }

        public void setNumPartida(int numPartida) {
            this.numPartida = numPartida;
        }
    }
}
