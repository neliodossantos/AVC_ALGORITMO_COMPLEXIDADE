package Entity;

import Interface.ISocio;

public class SocioHonorario extends Socio implements ISocio {
    public SocioHonorario(String nome, String email , String morada , String telefone , String numeroContribuinte, String bilheteIdentidade){
        super(email,nome,morada,telefone,numeroContribuinte,bilheteIdentidade);
    }
    @Override
    public boolean podeSerDirigente() {
        return true;
    }
    @Override
    public boolean podeSerHonorario() {
        return true;
    }
}
