package Entity;
import Interface.IAtividadeDesportiva;

import java.time.LocalDate;

public class AtividadeDesportiva {
    private String nome;
    private SocioOrdinario [] sociosOrdinarioInscritos;
    private SocioHonorario [] sociosHonorarioInscritos;
    private SocioDirigente [] sociosDirigenteInscritos;
    private Campeonato [] campeonatos;
    private final int maxSocios  = 100;
    private  static int totalSocioDirigente = 0;
    private  static int totalSocioOrdinario = 0;
    private  static int totalSocioHonorario = 0;
    private int totalCampeonatos;
    private Espaco espaco;

    public AtividadeDesportiva(String nome, Espaco espaco){
        this.nome = nome;
        this.espaco = espaco;
        this.sociosDirigenteInscritos = new SocioDirigente[maxSocios];
        this.sociosHonorarioInscritos = new SocioHonorario[maxSocios];
        this.sociosOrdinarioInscritos = new SocioOrdinario[maxSocios];
        this.campeonatos = new Campeonato[100];
    }

    public int getTotalSocioDirigente() {
        return totalSocioDirigente;
    }
    public void setTotalSocioDirigente(int totalSocioDirigente) {
        AtividadeDesportiva.totalSocioDirigente = totalSocioDirigente;
    }

    public int getTotalSocioOrdinario() {
        return totalSocioOrdinario;
    }

    public void setTotalSocioOrdinario(int totalSocioOrdinario) {
        AtividadeDesportiva.totalSocioOrdinario = totalSocioOrdinario;
    }

    public int getTotalSocioHonorario() {
        return totalSocioHonorario;
    }

    public void setTotalSocioHonorario(int totalSocioHonorario) {
        AtividadeDesportiva.totalSocioHonorario = totalSocioHonorario;
    }

    public SocioHonorario[] getSociosHonorarioInscritos() {return sociosHonorarioInscritos;}
    public SocioOrdinario[] getSociosOrdinarioInscritos() {return sociosOrdinarioInscritos;}
    public SocioDirigente[] getSociosDirigenteInscritos() {return sociosDirigenteInscritos;}
    public String getNome() {
        return nome;
    }
    public void setNome(String nome) {
        this.nome = nome;
    }
    public Campeonato[] getCampeonatos() {
        return campeonatos;
    }
    public void setCampeonatos(Campeonato[] campeonatos) {
        this.campeonatos = campeonatos;
    }

    public int getTotalCampeonatos() {
        return totalCampeonatos;
    }
    public void setTotalCampeonatos(int totalCampeonatos) {
        this.totalCampeonatos = totalCampeonatos;
    }
}
