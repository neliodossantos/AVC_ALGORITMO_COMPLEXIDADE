package Entity;

public class Espaco {
    private  String designacao;
    private  SocioDirigente socioDirigente;

    public  Espaco(String designacao , SocioDirigente socioDirigente){
        this.designacao = designacao;
        this.socioDirigente = socioDirigente;
    }
    public String getDesignacao() {
        return designacao;
    }

    public void setDesignacao(String designacao) {
        this.designacao = designacao;
    }

    public SocioDirigente getSocioDirigente() {
        return socioDirigente;
    }

    public void setSocioDirigente(SocioDirigente socioDirigente) {
        this.socioDirigente = socioDirigente;
    }
}
