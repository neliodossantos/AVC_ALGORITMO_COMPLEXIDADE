package Entity;

public class Socio {
    private String nome;
    private int numeroSocio;
    private String bilheteIdentidade;
    private String numeroContribuinte;
    private String morada;
    private String telefone;
    private String email;
    private boolean podeInscrever = true;
    public Socio(String email , String nome , String morada , String telefone , String numeroContribuinte, String bilheteIdentidade){
        this.nome = nome;
        this.bilheteIdentidade = bilheteIdentidade;
        this.numeroSocio = numeroSocio;
        this.morada = morada;
        this.telefone = telefone;
        this.numeroContribuinte = numeroContribuinte;
        this.email = email;
    }
    public String getNome() {return this.nome;}
    public void setNome(String nome) {
        this.nome = nome;
    }
    public int getNumeroSocio() {
        return numeroSocio;
    }
    public String getBilheteIdentidade() {
        return bilheteIdentidade;
    }
    public String getEmail() {
        return email;
    }
    public String getMorada() {
        return morada;
    }
    public String getNumeroContribuinte() {
        return numeroContribuinte;
    }
    public void setBilheteIdentidade(String bilheteIdentidade) {
        this.bilheteIdentidade = bilheteIdentidade;
    }
    public void setNumeroSocio(int numeroSocio) {
        this.numeroSocio = numeroSocio;
    }
    public void setNumeroContribuinte(String numeroContribuinte) {
        this.numeroContribuinte = numeroContribuinte;
    }
    public String getTelefone() {
        return telefone;
    }
    public void setEmail(String email) {
        this.email = email;
    }
    public void setMorada(String morada) {
        this.morada = morada;
    }
    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }
    public  boolean getPodeInserir(){
        return this.podeInscrever;
    }
    public void setPodeInscrever(boolean podeInscrever) {
        this.podeInscrever = podeInscrever;
    }
}
