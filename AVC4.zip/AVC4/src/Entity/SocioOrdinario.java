package Entity;
import Interface.ISocio;

public class SocioOrdinario extends Socio implements ISocio {
    public SocioOrdinario(String nome, String email , String morada , String telefone , String numeroContribuinte, String bilheteIdentidade){
        super(email,nome,morada,telefone,numeroContribuinte,bilheteIdentidade);
    }
    @Override
    public boolean podeSerDirigente() {
        return false;
    }
    @Override
    public boolean podeSerHonorario() {
        return false;
    }
}
