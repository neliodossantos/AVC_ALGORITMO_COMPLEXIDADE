package Entity;

import Interface.ISocio;

public class SocioDirigente extends Socio  implements ISocio {
    private int anoMandato;
    public SocioDirigente( int anoMandato,  String nome, String email , String morada , String telefone , String numeroContribuinte, String bilheteIdentidade){
        super(email,nome,morada,telefone,numeroContribuinte,bilheteIdentidade);
        this.anoMandato = anoMandato;
    }
    public int getAnoMandato() {
        return anoMandato;
    }
    public void setAnoMandato(int anoMandato) {
        this.anoMandato = anoMandato;
    }
    @Override
    public boolean podeSerDirigente() {
        return true;
    }
    @Override
    public boolean podeSerHonorario() {
        return true;
    }

}
