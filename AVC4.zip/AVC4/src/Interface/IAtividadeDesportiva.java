package Interface;

import Entity.*;

import java.time.LocalDate;

public interface IAtividadeDesportiva {
    public void adicionarActividade(AtividadeDesportiva atividadeDesportiva);

    public void buscarTodos();

    public void buscarCampeonatos();

    public void realizarCampeonato(AtividadeDesportiva atividadeDesportiva, Campeonato campeonato);

    public void inscreverSocioOrdinario(AtividadeDesportiva atividadeDesportiva, SocioOrdinario socioOrdinario);

    public void inscreverSocioHonorario(AtividadeDesportiva atividadeDesportiva, SocioHonorario socioOrdinario);

    public void inscreverSocioDirigente(AtividadeDesportiva atividadeDesportiva, SocioDirigente socioOrdinario);

    public void cadastrarEquipa(AtividadeDesportiva atividadeDesportiva, Campeonato campeonato, Campeonato.Equipa equipa);
    public void cadastrarPartida(AtividadeDesportiva atividadeDesportiva , Campeonato campeonato , Campeonato.Partida partida);


}