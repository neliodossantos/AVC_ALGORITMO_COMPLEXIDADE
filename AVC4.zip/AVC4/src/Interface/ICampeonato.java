package Interface;

import Entity.Campeonato;

public interface ICampeonato {
    public void adicionarCampeonato(Campeonato campeonato);
    public void adicionarEquipa(Campeonato campeonato , Campeonato.Equipa equipa);


}
