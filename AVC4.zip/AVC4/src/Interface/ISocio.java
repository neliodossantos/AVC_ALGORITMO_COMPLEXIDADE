package Interface;

public interface ISocio {
    public  boolean podeSerDirigente();
    public  boolean podeSerHonorario();
}
