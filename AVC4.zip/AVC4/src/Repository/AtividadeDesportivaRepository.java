package Repository;

import Entity.*;
import Interface.IAtividadeDesportiva;

import java.time.LocalDate;

public class AtividadeDesportivaRepository  implements IAtividadeDesportiva {
    private static AtividadeDesportiva[] atividadeDesportivas = new AtividadeDesportiva [100];
    private static SocioOrdinario [] socioOrdinarios;
    private static SocioHonorario [] socioHonorarios;
    private static SocioDirigente [] socioDirigentes;
    private static Campeonato[] campeonatos;
    private static Campeonato.Equipa[] equipas;
    private static Campeonato.Partida[] partidas;
    private static  int  totalCampeonato = 0;

    private static  int totalSocios = 0;
    private static  int totalActividades = 0;

    @Override
    public void adicionarActividade(AtividadeDesportiva atividadeDesportiva)
    {
        if(totalActividades < atividadeDesportivas.length){
            atividadeDesportivas[totalActividades++] = atividadeDesportiva;
            System.out.println("Adicionou uma actividade com nome: " + atividadeDesportiva.getNome());
        }
        else
            System.out.println("Não foi possivel adicionar.");
    }
    @Override
    public void inscreverSocioOrdinario(AtividadeDesportiva atividadeDesportiva , SocioOrdinario socioOrdinario)
    {
        int total = atividadeDesportiva.getTotalSocioOrdinario();
        for(AtividadeDesportiva atividade : atividadeDesportivas){
                if(atividade != null){
                    if(atividade == atividadeDesportiva){
                       socioOrdinarios  =  atividade.getSociosOrdinarioInscritos();
                        if(total < socioOrdinarios.length){
                            for(SocioOrdinario ordinario : socioOrdinarios){
                                if(ordinario != null){
                                    if(socioOrdinario.getNome().equals(ordinario.getNome())){
                                        System.out.println("Não podes se inscrever o " + socioOrdinario.getNome() + " em mais actividades ");
                                        System.out.println("Ele ja pertence a uma actividade.");
                                        socioOrdinario.setPodeInscrever(false);
                                        break;
                                    }
                                }
                            }
                            if(socioOrdinario.getPodeInserir() == true){
                                socioOrdinarios[total++]  = socioOrdinario;
                                totalSocios++;
                                socioOrdinario.setNumeroSocio(totalSocios);
                                atividade.setTotalSocioOrdinario(total);
                                System.out.println("Adicionou " + socioOrdinario.getNome() +  "  um socio na actividade" + atividadeDesportiva.getNome());
                            }
                        }
                    }
                }
        }
    }
    @Override
    public void inscreverSocioHonorario(AtividadeDesportiva atividadeDesportiva , SocioHonorario socioHonorario)
    {
        int total = atividadeDesportiva.getTotalSocioHonorario();
        for(AtividadeDesportiva atividade : atividadeDesportivas){
            if(atividade != null){
                if(atividade == atividadeDesportiva){
                    socioHonorarios  =  atividade.getSociosHonorarioInscritos();
                    if(total < socioHonorarios.length){
                        socioHonorarios[total++]  = socioHonorario;
                        atividade.setTotalSocioOrdinario(total);
                        totalSocios++;
                        socioHonorario.setNumeroSocio(totalSocios);
                        System.out.println("Inscreveu o socio " + socioHonorario.getNome() +  "   na actividade" + atividadeDesportiva.getNome());
                    }
                }
            }
        }
    }

    @Override
    public void inscreverSocioDirigente(AtividadeDesportiva atividadeDesportiva , SocioDirigente socioDirigente)
    {
        int total = atividadeDesportiva.getTotalSocioDirigente();
        for(AtividadeDesportiva atividade : atividadeDesportivas){
            if(atividade != null){
                if(atividade == atividadeDesportiva){
                    socioDirigentes  =  atividade.getSociosDirigenteInscritos();
                    if(total < socioDirigentes.length){
                        socioDirigentes[total++]  = socioDirigente;
                        atividade.setTotalSocioDirigente(total);
                        totalSocios++;
                        socioDirigente.setNumeroSocio(totalSocios);
                        System.out.println("Inscreveu o socio " + socioDirigente.getNome() +  "   na actividade" + atividadeDesportiva.getNome());
                    }
                }
            }
        }
    }
    @Override
    public void buscarTodos() {
        for (AtividadeDesportiva atividadeDesportiva : atividadeDesportivas){
            if(atividadeDesportiva != null){
                System.out.println("Nome da Actividade: " + atividadeDesportiva.getNome());
                 for (SocioDirigente socioDirigente : atividadeDesportiva.getSociosDirigenteInscritos()){
                     if (socioDirigente != null){
                         System.out.println("Nome do Socio Dirigente: " + socioDirigente.getNome());
                     }
                 }
                for (SocioHonorario socioHonorario  : atividadeDesportiva.getSociosHonorarioInscritos()){
                    if (socioHonorario != null){
                        System.out.println("Nome do Socio Honorario: " + socioHonorario.getNome());
                    }
                }
                for (SocioOrdinario socioOrdinario : atividadeDesportiva.getSociosOrdinarioInscritos()){
                    if (socioOrdinario != null){
                        System.out.println("Nome do Socio Ordinario: " + socioOrdinario.getNome());
                    }
                }
            }
        }
    }
    @Override
    public void buscarCampeonatos() {
        if(totalActividades > 0){
            for (AtividadeDesportiva atividadeDesportiva : atividadeDesportivas){
                if(atividadeDesportiva !=  null){
                    for(Campeonato campeonato : atividadeDesportiva.getCampeonatos()){
                        if(campeonato != null){
                            System.out.println("Campeonato : " + campeonato.getAtividade().getNome());
//                            for (Campeonato.Equipa equipa : campeonato.getEquipasParticipantes()){
//                                if (equipa != null){
//                                    System.out.println("Equipa : " + equipa.getNome());
//                                }
//                            }
                            for (Campeonato.Partida partida : campeonato.getPartidas()){
                                if (partida != null){
                                    System.out.println("Partida : " + partida.getNumPartida());
                                    System.out.println("Time de Casa : " + partida.getEquipas()[0].getNome());
                                    System.out.println("Time de Fora : " + partida.getEquipas()[1].getNome());
                                    System.out.println("Resultado da CASA : " + partida.getResultado()[0] + " X " + "Resultado da Fora " + partida.getResultado()[1]);
                                }
                            }
                        }
                    }
                }
            }
        }else{
            System.out.println("Sem campeonato em nenhuma actividade");
        }
    }
    @Override
    public void realizarCampeonato(AtividadeDesportiva atividadeDesportiva , Campeonato campeonato) {
        int total = atividadeDesportiva.getTotalCampeonatos();
        for(AtividadeDesportiva atividade : atividadeDesportivas){
            if(atividade != null){
                if(atividade == atividadeDesportiva){
                    campeonatos  =  atividade.getCampeonatos();
                    if(total < campeonatos.length){
                        campeonatos[total++]  = campeonato;
                        atividade.setTotalCampeonatos(total);
                    }
                }
            }
        }
    }
    @Override
    public void cadastrarEquipa(AtividadeDesportiva atividadeDesportiva , Campeonato campeonato , Campeonato.Equipa equipa) {
        for(AtividadeDesportiva atividade : atividadeDesportivas){
            if(atividade != null){
                if(atividade == atividadeDesportiva){
                    for(Campeonato camp : atividadeDesportiva.getCampeonatos()) {
                        if (camp != null) {
                            if(camp == campeonato){
                                int total = camp.getTotalEquipa();
                                equipas =  camp.getEquipasParticipantes();
                                equipas[total++] = equipa;
                                camp.setTotalEquipa(total);
                            }else{
                                System.out.println("Não encontrou o campeonato");
                            }
                        }
                    }
                }
            }
        }
    }

    @Override
    public void cadastrarPartida(AtividadeDesportiva atividadeDesportiva , Campeonato campeonato , Campeonato.Partida partida) {
        for(AtividadeDesportiva atividade : atividadeDesportivas){
            if(atividade != null){
                if(atividade == atividadeDesportiva){
                    for(Campeonato camp  : atividadeDesportiva.getCampeonatos()) {
                        if (camp != null) {
                            if(camp == campeonato){
                                int total = camp.getTotalPartidas();
                                partidas =  camp.getPartidas();
                                partidas[total++] = partida;
                                partida.setNumPartida(total);
                                camp.setTotalPartidas(total);
                            }else{
                                System.out.println("Não encontrou o campeonato");
                            }
                        }
                    }
                }
            }
        }
    }
}
