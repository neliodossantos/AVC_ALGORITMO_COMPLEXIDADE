import Entity.*;
import Repository.AtividadeDesportivaRepository;

import java.time.LocalDate;
import java.util.Locale;

public class Main {
    public static void main(String[] args) {
        AtividadeDesportivaRepository  atividadeDesportivaRepository = new AtividadeDesportivaRepository();


        SocioOrdinario socioOrdinario1 =  new SocioOrdinario("Nelio","neliodossantos15@gmail.com","Hoje Yhea Henda","923600657","A01929201221","A081010299101");
        SocioOrdinario socioOrdinario2 =  new SocioOrdinario("Ana","neliodossantos15@gmail.com","Hoje Yhea Henda","923600657","A01929201221","A081010299101");
        SocioDirigente socioDirigente =  new SocioDirigente(2002,"Miguel","neliodossantos15@gmail.com","Hoje Yhea Henda","923600657","A01929201221","A081010299101");

        Espaco espaco1 = new Espaco("Campo de Jogos A",socioDirigente);
        Espaco espaco2 = new Espaco("Campo de Jogos B",socioDirigente);

        AtividadeDesportiva atividadeDesportiva1 =  new AtividadeDesportiva ("Futebol",espaco1);
        AtividadeDesportiva atividadeDesportiva2 =  new AtividadeDesportiva ("Andebol",espaco2);

        atividadeDesportivaRepository.adicionarActividade(atividadeDesportiva1);
        atividadeDesportivaRepository.adicionarActividade(atividadeDesportiva2);

        atividadeDesportivaRepository.inscreverSocioOrdinario(atividadeDesportiva1,socioOrdinario1);

        atividadeDesportivaRepository.inscreverSocioOrdinario(atividadeDesportiva1,socioOrdinario2);
        atividadeDesportivaRepository.inscreverSocioDirigente(atividadeDesportiva1,socioDirigente);
        atividadeDesportivaRepository.inscreverSocioOrdinario(atividadeDesportiva1,socioOrdinario1);

        atividadeDesportivaRepository.buscarTodos();


        LocalDate data = LocalDate.now();
        Campeonato campeonato1 = new Campeonato(atividadeDesportiva1,data,data);
        atividadeDesportivaRepository.realizarCampeonato(atividadeDesportiva1,campeonato1);

        Campeonato.Equipa equipa1 = campeonato1.new Equipa("Remos Rapido","Golfinho");
        Campeonato.Equipa equipa2 = campeonato1.new Equipa("Remos Lento","Tubarao Pequeno");
        Campeonato.Partida partida1 = campeonato1.new Partida(equipa1,equipa2,4,2);


        atividadeDesportivaRepository.cadastrarEquipa(atividadeDesportiva1,campeonato1,equipa1);
        atividadeDesportivaRepository.cadastrarPartida(atividadeDesportiva1,campeonato1,partida1);


        atividadeDesportivaRepository.buscarCampeonatos();



    }
}